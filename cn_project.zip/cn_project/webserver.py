import sys
import datetime
import threading
from _thread import *

print_lock = threading.Lock()

def threaded(connectionSocket):
		
	while True:

		try:
			clientmessage=connectionSocket.recv(1024)
			if (clientmessage!=''):
				print"Request details:", clientmessage
				filename = clientmessage.split()[1]

				file = open(filename[1:])
				outputdata =file.read()
				connectionSocket.send("\nHTTP/1.1 200 OK\n")
				for c in range(0,len(outputdata)):
					connectionSocket.sendall(outputdata[c])
				print 'Response:File Sent to client....'
				print "--------------------------------------------------------------------------"
				#connectionSocket.close()
			
			else:
				print_lock.release()
				break

		except IOError:
			print "clientmessage",clientmessage
			if filename!="/favicon.ico":
				print IOError
				print "Response:404 Not Found sent to client......."
				print "--------------------------------------------------------------------------"
			else:
				print "Additional ""Get favicon.ico"" request sent by Browser.."
				print "--------------------------------------------------------------------------"
		connectionSocket.send("\n404 Not Found\n")
        #connectionSocket.close()
		connectionSocket.close()	
		

def Main():
	
	ServerSocket= socket(AF_INET, SOCK_STREAM)
	ServerPort=8080
	
	if (len(sys.argv)==2):
		ServerPort=int(sys.argv[1])

	Host = gethostname() 

	ServerSocket.bind(('',ServerPort))
	ServerSocket.listen(5)

	print 'Web server ready to serve on port',ServerPort,"..."
	filename=""

	while True:
		connectionSocket, addr =ServerSocket.accept()
		
		print_lock.acquire()

		print "\n"
    	print "--------------------------------------------------------------------------"

		print "TimeStamp",datetime.datetime.now(),"Request from", (gethostbyaddr(connectionSocket.getpeername()[0]))[0],(gethostbyaddr(connectionSocket.getpeername()[0]))[2]
		print "Client Host Name:",(gethostbyaddr(connectionSocket.getpeername()[0]))[0]  
		print "Client Socket Family:",connectionSocket.family
		print "Client Socket Type:",connectionSocket.type
		print "Client Protocol:", connectionSocket.proto
		print "Client Socket- get Peer Name:", connectionSocket.getpeername()
		print "Client Timeout:",connectionSocket.gettimeout()

		start_new_thread(threaded, (connectionSocket,))

	ServerSocket.close()
		

